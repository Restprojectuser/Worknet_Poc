package com.cherrywork.worknet.aspect;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;

import javax.persistence.Entity;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cherrywork.worknet.parser.helper.ActionDto;

import ch.qos.logback.classic.Logger;

@Component
@Aspect
public class AspectUtil {
	private final Logger logger= (Logger) LoggerFactory.getLogger(this.getClass());
	
	
	@Autowired
	AsyncExecuter asyncExecuter;
	
//	@Pointcut("within(@org.springframework.web.bind.annotation.DetailController *)")
	public void executeScript(ActionDto dto, String baseurl,HashMap<String,String> req) {
		String uri ="https://crudservicesdev.cherryworkproducts.com/crud/api/fetchQuery?converterName=map";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Detail> requestEntity = new HttpEntity<>( headers);
		ResponseEntity<String> responseEntity=restTemplate.exchange(baseurl+"getScripts", HttpMethod.GET, requestEntity, String.class);
	    HttpStatus statuscode = responseEntity.getStatusCode();
	    System.out.println("statuscode-" + statuscode);
		String user = responseEntity.getBody();
		System.out.println("responsebody-" + user);
		HttpHeaders responseHeaders = responseEntity.getHeaders();
		System.out.println("responseHeaders-" + responseHeaders);
//	String result = restTemplate.postForEntity(uri, String.class, dto.getTasks().get(0).getSystemId(), dto.getTasks().get(0).getProcessId(),dto.getTasks().get(0).getTaskId());
	//ResponseEntity<Detail>postForEntity("uri", {"query":"fetchTestTableByIDs","args":["abhishek1", "kumar1","age1","height1"]}Class<Detail> JSON); 
//		return result;
		
		
		 try{

	            ScriptEngine ee = new ScriptEngineManager()
	                    .getEngineByName("Nashorn");
	            ee.eval(req.get("jScript"));
	        }catch (ScriptException e) {
	        }
		
		
	}

	@After(value = "execution(* com.cherrywork.worknet.parser.controller.TaskActionController.*(..))")
	public void afterAdvice(JoinPoint joinPoint) {
		ActionDto dto = (ActionDto) joinPoint.getArgs()[1];
		String auth = (String) joinPoint.getArgs()[2];
		executeScript(dto, auth, null);
		asyncExecuter.asyncMethodWithReturnType(dto,auth);
//		executeScript(dto);
//		System.out.print(false);
	}

//	@After(value= "execution(* com.cherrywork.worknet.parser.controller.TaskActionController.*(..))")
//	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable{
//		if(logger.isInfoEnabled()) {
//			logger.info("Enter: {},{} with argument[s]={}",
//					joinPoint.getSignature().getDeclaringType(),
//					joinPoint.getSignature().getName(),
//					Arrays.toString(joinPoint.getArgs()));
//		}
//		Object result = joinPoint.proceed();
//		if(logger.isInfoEnabled()) {
//			logger.info("Exit: {},{} with result ={}",
//					joinPoint.getSignature().getDeclaringType(),
//					joinPoint.getSignature().getName(),result);
//		}
//		return result;
//	
//		
//	}
}

