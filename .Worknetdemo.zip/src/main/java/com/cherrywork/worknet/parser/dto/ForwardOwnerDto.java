package com.cherrywork.worknet.parser.dto;

import lombok.Data;

@Data
public class ForwardOwnerDto {

	private String ownerId;
	private String ownerType;

}
