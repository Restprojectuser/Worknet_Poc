package com.cherrywork.worknet.parser.util;

import java.util.AbstractMap.SimpleEntry;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FlatMapUtil {
	private FlatMapUtil() {
		throw new AssertionError("No instances for you!");
	}

	public static Map<String, Object> flatten(Map<String, Object> map, String referenceId) {
		return map.entrySet().stream().parallel().flatMap(FlatMapUtil::flatten).collect(LinkedHashMap::new,
				(m, e) -> m.put(referenceId + "/" + e.getKey(), e.getValue()), LinkedHashMap::putAll);
	}

	public static Map<String, Object> flatten(Map<String, Object> map) {
		return map.entrySet().stream().parallel().flatMap(FlatMapUtil::flatten).collect(LinkedHashMap::new,
				(m, e) -> m.put("/" + e.getKey(), e.getValue()), LinkedHashMap::putAll);
	}

	private static Stream<Map.Entry<String, Object>> flatten(Map.Entry<String, Object> entry) {

		if (entry == null) {
			return Stream.empty();
		}

		if (entry.getValue() instanceof Map<?, ?>) {
			Map<?, ?> properties = (Map<?, ?>) entry.getValue();
			return properties.entrySet().stream()
					.flatMap(e -> flatten(new SimpleEntry<>(entry.getKey() + "/" + e.getKey(), e.getValue())));
		}

		if (entry.getValue() instanceof List<?>) {
			List<?> list = (List<?>) entry.getValue();
			return IntStream.range(0, list.size())
					.mapToObj(i -> new SimpleEntry<String, Object>(entry.getKey() + "/" + i, list.get(i)))
					.flatMap(FlatMapUtil::flatten);
		}

		return Stream.of(entry);
	}

}
