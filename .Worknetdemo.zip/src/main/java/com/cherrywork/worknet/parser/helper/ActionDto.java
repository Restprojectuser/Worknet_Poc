package com.cherrywork.worknet.parser.helper;

import java.util.List;

import lombok.Data;

/**
 * @author Shruti.Ghanshyam
 *
 */
@Data
public class ActionDto {

	private List<TaskDto> tasks;

}
